import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ROUTING';
  val:string='';
  constructor(private route:Router){}
  selectedCountry(){
    console.log("Selected COUNTRY: "+this.val);
    if(this.val=='INDIA')
    {
      this.route.navigate(['INDIA']);
    }
    else if(this.val=='UK')
    {
      this.route.navigate(['UK']);
    }
    else if(this.val=='USA')
    {
      this.route.navigate(['USA']);
    }
    else
    {
      console.log("Inavlid");
    }
  }
}
