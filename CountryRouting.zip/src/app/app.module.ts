import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndiaComponent } from './components/india/india.component';
import { UkComponent } from './components/uk/uk.component';
import { UsaComponent } from './components/usa/usa.component';

@NgModule({
  declarations: [
    AppComponent,
    IndiaComponent,
    UkComponent,
    UsaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
