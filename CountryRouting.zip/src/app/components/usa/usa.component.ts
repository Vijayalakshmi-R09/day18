import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-usa',
  templateUrl: './usa.component.html',
  styleUrls: ['./usa.component.css']
})
export class UsaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  display()
  {
    console.log("Details Submitted");
  }


}
