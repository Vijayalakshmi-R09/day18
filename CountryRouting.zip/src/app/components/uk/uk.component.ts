import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-uk',
  templateUrl: './uk.component.html',
  styleUrls: ['./uk.component.css']
})
export class UkComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  display()
  {
    console.log("Details Submitted");
  }


}
