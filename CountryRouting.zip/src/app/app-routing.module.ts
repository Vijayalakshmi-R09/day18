import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IndiaComponent } from './components/india/india.component';
import { UkComponent } from './components/uk/uk.component';
import { UsaComponent } from './components/usa/usa.component';
const routes: Routes = [
  {path:'INDIA',component:IndiaComponent},
  {path:'UK',component:UkComponent},
  {path:'USA',component:UsaComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
