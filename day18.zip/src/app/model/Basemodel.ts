export abstract class BaseClass{
    
}